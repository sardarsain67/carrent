<?php
// Start the PHP session
session_start();

// Include your server.php file for database connection
include('server.php');

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: index.html');
    exit();
}

// Check if the form data is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form data
    $carId = $_POST['carId'];
    $username = $_POST['username'];
    $scheduleDate = $_POST['scheduleDate'];
    $scheduleTime = $_POST['scheduleTime'];

    // Insert booking data into the database
    $query = "INSERT INTO bookings (car_id, username, schedule_date, schedule_time) 
              VALUES ('$carId', '$username', '$scheduleDate', '$scheduleTime')";

    if ($conn->query($query)) {
        // Booking successful
        $response = ['success' => true, 'message' => 'Booking successful.'];
    } else {
        // Booking failed
        $response = ['success' => false, 'message' => 'Booking failed. Please try again.'];
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);

    // Close the database connection
    $conn->close();
} else {
    // Invalid request method
    http_response_code(405); // Method Not Allowed
    echo 'Invalid request method.';
}
?>
