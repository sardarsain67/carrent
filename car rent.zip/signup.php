<?php
include('server.php');

// Define a fixed salt (replace this with your own secure, random salt)
$fixedSalt = 'pmsain'; // Make sure this is a long, unique string

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the form data
    $username = $_POST['username'];
    $email = $_POST['email']; // Added line to get email
    $password = $_POST['password'];
    $security_question = $_POST['security_question'];
    $security_answer = $_POST['security_answer'];

    // Check if the username already exists
    $check_username_query = "SELECT * FROM userlogin WHERE username='$username'";
    $result_username = mysqli_query($conn, $check_username_query);
    if (mysqli_num_rows($result_username) > 0) {
        // Username already exists
        echo "<script>alert('Username already in use. Please choose another username.');</script>";
        echo "<script>window.location.href = 'signup.html';</script>";
        exit();
    }

    // Check if the email already exists
    $check_email_query = "SELECT * FROM userlogin WHERE email='$email'";
    $result_email = mysqli_query($conn, $check_email_query);
    if (mysqli_num_rows($result_email) > 0) {
        // Email already exists
        echo "<script>alert('Email already in use. Please use another email address.');</script>";
        echo "<script>window.location.href = 'signup.html';</script>";
        exit();
    }

    // Combine the password with the fixed salt
    $passwordWithSalt = $password . $fixedSalt;
    // Hash the password with bcrypt (recommended)
    $hashed_password = password_hash($passwordWithSalt, PASSWORD_BCRYPT);

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format. Please enter a valid email address.');</script>";
        // You might want to redirect the user back to the signup form here
        exit();
    }

    // Prepare the SQL query to insert the user data into the userlogin table
    $sql = "INSERT INTO userlogin (username, email, password, sec_answer) VALUES ('$username', '$email', '$hashed_password', '$security_answer')";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        // Signup successful, show an alert and redirect to login page
        echo "<script>alert('Signup successful! Please login with your new account.');</script>";
        header("Location: signin.html");
        exit();
    } else {
        // Error in inserting data
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
