<?php
// Include your server.php file for database connection
include('server.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['postId'], $_POST['newStatus'], $_POST['newPaymentAmount'], $_POST['newPaymentStatus'])) {
    // Get form data
    $bookingId = $_POST['postId'];
    $newStatus = $_POST['newStatus'];
    $newPaymentAmount = $_POST['newPaymentAmount'];
    $newPaymentStatus = $_POST['newPaymentStatus'];

    // Update the booking details in the database
    $updateQuery = "UPDATE bookings SET status = ?, payment_amount = ?, payment_status = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateQuery);
    $updateStmt->bind_param("idis", $newStatus, $newPaymentAmount, $newPaymentStatus, $bookingId);

    if ($updateStmt->execute()) {
        // Update successful
        echo json_encode(['success' => true, 'message' => 'Booking details updated successfully']);
    } else {
        // Update failed
        echo json_encode(['success' => false, 'message' => 'Error updating booking details']);
    }

    // Close the statement
    $updateStmt->close();
} else {
    // Handle the case where form data is not provided
    echo json_encode(['success' => false, 'message' => 'Form data not provided']);
}

// Close the database connection
$conn->close();
?>
