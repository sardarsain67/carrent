<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <!-- Add the Bootstrap CSS link here -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7Rxna...etc" crossorigin="anonymous">
</head>
<body>
    <div class="container mt-5">
        <div class="alert alert-success" role="alert">
            Thank you for your submission!
        </div>
        <a href="car_home.php" class="btn btn-primary">Return to Homepage</a>
        
    </div>
   
    <!-- Add the Bootstrap JavaScript and jQuery links here if needed -->
    <!-- Add your scripts if needed -->
</body>
</html>
