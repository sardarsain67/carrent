<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Adjust the path based on your project structure

function generateOTP() {
    // Generate a random 6-digit OTP
    return strval(mt_rand(100000, 999999));
}

function sendOTP($email, $otp) {
    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Gmail SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'sardarsainbusiness@gmail.com'; // Replace with your email username
        $mail->Password = 'yqcbolxoxaxcwyqn'; // Replace with your app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587; // Adjust the port if needed

        // Recipients
        $mail->setFrom('sardarsainbusiness@gmail.com', 'pmsain'); // Replace with your email and name
        $mail->addAddress($email); // Add the recipient email address

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'OTP for Car Rental Pro Sign Up';
        $mail->Body = 'Your OTP for signing up with Car Rental Pro is: <strong>' . $otp . '</strong>. Please use this OTP to complete the registration process.';

        // Send the email
        $mail->send();

        return true;
    } catch (Exception $e) {
        // Handle any exceptions
        return false;
    }
}

// Main logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming you get the email address from the POST request
    $email = $_POST['email'];

    // Generate OTP
    $otp = generateOTP();

    // Save the OTP for verification
    // You might want to store it in a database or session
    // For simplicity, we'll store it in a session variable here
    session_start();
    $_SESSION['otp'] = $otp;

    // Send OTP via email
    $isSent = sendOTP($email, $otp);

    if ($isSent) {
        echo json_encode(['success' => true, 'message' => 'OTP sent successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to send OTP']);
    }
} else {
    // Handle other request methods or direct access to this file
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>
