<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming you get the entered OTP from the POST request
    $enteredOtp = $_POST['otp'];

    // Get the stored OTP from the session
    $storedOtp = isset($_SESSION['otp']) ? $_SESSION['otp'] : '';

    // Compare the entered OTP with the stored OTP
    if ($enteredOtp === $storedOtp) {
        echo json_encode(['success' => true, 'message' => 'OTP verification successful']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid OTP']);
    }
} else {
    // Handle other request methods or direct access to this file
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>
